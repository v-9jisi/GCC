$users = Import-Csv -Path data.csv
$TimeStamp = (Get-Date).ToString('MMddyyyhhmmss')
$TempFile = 'temp_storage.parameters.json'
$TempExist = Test-Path $TempFile

$CreateRG= Read-Host "Do you want to create other resources or choose an existing one
'Select from followint options as 0 or 1
' [0] Choose from existing 
' [1] Create a new Resource Group
'"

if($CreateRG -eq '0'){
    $ResourceGroup = Read-Host "Enter the name of Resource Group: if that doesn't exists a new one will be created automatically "
    $GetResourceGroup = Get-AzResourceGroup -Name $ResourceGroup

    $GetResourceGroup
    break

}elseif ($CreateRG -eq '1') {
    $ResourceGroup = Read-Host "Enter the Resource Group name: "
    $ResourceGroupRegion = Read-Host "Enter Resource Group Region: "
    New-AzResourceGroup -Name $ResourceGroup -Location $ResourceGroupRegion

}else {
    Write-Host $CreateRG + "is invalid Input"
}


if($TempExist){
    Remove-Item $TempFile
}


$GetJSONTemplate = Get-Content 'storage.parameters.json'
for($i = 0; $i -lt $users.length;$i++){
    $StorageAccountName = $users[$i].FirstName.ToString().ToLower() +$users[$i].LastName.ToString().ToLower() + $TimeStamp
    $StorageRegion = $users[$i].Location
    $StorageAccountName
    $StorageRegion
    New-Item -Path $TempFile -ItemType File
    $UpdatedContent = $GetJSONTemplate.Replace("{StorageAccountName}",$StorageAccountName).Replace("{StorageAccountLocation}",$StorageRegion)
    Set-Content $TempFile $UpdatedContent
    New-AzResourceGroupDeployment -ResourceGroupName $ResourceGroup -TemplateFile "storage.json" -TemplateParameterFile $TempFile
    $UpdatedContent = $GetJSONTemplate.Replace($StorageAccountName,"{StorageAccountName}").Replace($StorageRegion,"{StorageAccountLocation}")
}

